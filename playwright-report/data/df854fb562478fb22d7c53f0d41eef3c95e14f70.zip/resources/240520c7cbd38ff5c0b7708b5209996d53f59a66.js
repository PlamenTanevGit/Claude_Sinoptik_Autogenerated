/* cookies */

function SetCookie(name,value,expires,path,domain,secure){
    var today=new Date();
    today.setTime(today.getTime());
    if(expires) expires=expires*1000*60*60*24;
    var expires_date = new Date(today.getTime()+(expires));
    document.cookie=name+"="+escape(value)+((expires)?";expires="+expires_date.toGMTString():"")+((path)?";path="+path:"")+((domain)?";domain="+domain:"")+((secure)?";secure":"");
}

function GetCookie(name) {
    var start=document.cookie.indexOf(name+"=");
    var len=start+name.length+1;
    if((!start)&&(name!=document.cookie.substring(0,name.length))) return null;
    if(start==-1) return null;
    var end=document.cookie.indexOf(";",len);
    if(end==-1) end=document.cookie.length;
    return unescape(document.cookie.substring(len,end));
}
      
function DeleteCookie(name,path,domain){
    var exp=new Date();  
    exp.setTime(exp.getTime()-1); 
    if(GetCookie(name)) document.cookie=name+"="+((path)?";path="+path:"")+
        ((domain)?";domain="+domain:"" )+";expires="+exp.toGMTString();
}

function checkCoockie(domain){
    if (document.cookie.length) return 1;
    else return 0;
}

function AddLocation(location, name){
	let locationContainer = $('.myCities');
    var count = CountCookies('locations');
	locationContainer.show();
    if (count >= 5) { 
        alert('Може да добавите до 5 любими града!');
    } else {
        SetCookie('locations['+location+']',name,1500,'/','.sinoptik.bg');
        //if(GetCookie('deflocation')==null) SetCookie('deflocation',location,1500,'/','.sinoptik.bg');
    }
}

function RemoveLocation(location){
	let locationContainer = $('.myCities');
	let count = CountCookies('locations');
	if(count == 1) {
		locationContainer.hide();
		window.location.reload();
	}
    DeleteCookie('locations['+location+']','/','.sinoptik.bg');
    // if(GetCookie('deflocation')==location){
    //     var a = document.cookie.match('locations\[[0-9]*\]=[^;]+;*');
    //     a = a + '';
    //     a = a.match('[0-9]+');
    //     if(a != '' && a != null){
    //         SetCookie('deflocation',a,1500,'/','.sinoptik.bg');
    //     }else{
    //         DeleteCookie('deflocation','/','.sinoptik.bg');
    //     }
    // }
}

//call: onclick="RemoveDefaultLocation(); window.location.reload();"
function RemoveDefaultLocation(){
     DeleteCookie('deflocation','/','.sinoptik.bg');
}

function SetDefault(location){
    SetCookie('deflocation',location,1500,'/','.sinoptik.bg');
// if(GetCookie('locations['+location+']')==null) SetCookie('locations['+location+']',name,1500,'/','.sinoptik.bg');
}

function CountCookies(cookie_name) {
    var count = 0;
    if (document.cookie && document.cookie != '') {
        var cookiesArray = document.cookie.split('; ');
        for (var name in cookiesArray) {
            if (cookiesArray[name].match(cookie_name)) count++;
        }
    }
    return count;
}
/* end cookies */

// Vesti click counter
$(document).ready(function(){
  $('.vestiLink').click(function(){
	_gaq.push(['_trackEvent', 'Р‘Р»РѕРє Р’РµСЃС‚Рё.Р±Рі', 'РќРѕРІРёРЅР° '+$(this).attr('rel')]);
  });
});  

/*
 * jQuery Media Plugin for converting elements into rich media content.
 * Examples and documentation at: http://malsup.com/jquery/media/
 * Copyright (c) 2007-2008 M. Alsup
 * @author: M. Alsup
 * @version: 0.92 (24-SEP-2009)
 * @requires jQuery v1.1.2 or later
 * $Id: jquery.media.js 2460 2007-07-23 02:53:15Z malsup $
 */
;(function($) {

/**
 * Chainable method for converting elements into rich media.
 *
 * @param options
 * @param callback fn invoked for each matched element before conversion
 * @param callback fn invoked for each matched element after conversion
 */
$.fn.media = function(options, f1, f2) {
	if (options == 'undo') {
		return this.each(function() {
			var $this = $(this);
			var html = $this.data('media.origHTML');
			if (html)
				$this.replaceWith(html);
		});
	}

	return this.each(function() {
		if (typeof options == 'function') {
			f2 = f1;
			f1 = options;
			options = {};
		}
		var o = getSettings(this, options);
		// pre-conversion callback, passes original element and fully populated options
		if (typeof f1 == 'function') f1(this, o);

		var r = getTypesRegExp();
		var m = r.exec(o.src.toLowerCase()) || [''];

		o.type ? m[0] = o.type : m.shift();
		for (var i=0; i < m.length; i++) {
			fn = m[i].toLowerCase();
			if (isDigit(fn[0])) fn = 'fn' + fn; // fns can't begin with numbers
			if (!$.fn.media[fn])
				continue;  // unrecognized media type
			// normalize autoplay settings
			var player = $.fn.media[fn+'_player'];
			if (!o.params) o.params = {};
			if (player) {
				var num = player.autoplayAttr == 'autostart';
				o.params[player.autoplayAttr || 'autoplay'] = num ? (o.autoplay ? 1 : 0) : o.autoplay ? true : false;
			}
			var $div = $.fn.media[fn](this, o);

			$div.css('backgroundColor', o.bgColor).width(o.width);

			if (o.canUndo) {
				var $temp = $('<div></div>').append(this);
				$div.data('media.origHTML', $temp.html()); // store original markup
			}

			// post-conversion callback, passes original element, new div element and fully populated options
			if (typeof f2 == 'function') f2(this, $div[0], o, player.name);
			break;
		}
	});
};

/**
 * Non-chainable method for adding or changing file format / player mapping
 * @name mapFormat
 * @param String format File format extension (ie: mov, wav, mp3)
 * @param String player Player name to use for the format (one of: flash, quicktime, realplayer, winmedia, silverlight or iframe
 */
$.fn.media.mapFormat = function(format, player) {
	if (!format || !player || !$.fn.media.defaults.players[player]) return; // invalid
	format = format.toLowerCase();
	if (isDigit(format[0])) format = 'fn' + format;
	$.fn.media[format] = $.fn.media[player];
	$.fn.media[format+'_player'] = $.fn.media.defaults.players[player];
};

// global defautls; override as needed
$.fn.media.defaults = {
	standards:  false,      // use object tags only (no embeds for non-IE browsers)
	canUndo:    true,       // tells plugin to store the original markup so it can be reverted via: $(sel).mediaUndo()
	width:		400,
	height:		400,
	autoplay:	0,		   	// normalized cross-player setting
	bgColor:	'#ffffff', 	// background color
	params:		{ wmode: 'transparent'},	// added to object element as param elements; added to embed element as attrs
	attrs:		{},			// added to object and embed elements as attrs
	flvKeyName: 'file', 	// key used for object src param (thanks to Andrea Ercolino)
	flashvars:	{},			// added to flash content as flashvars param/attr
	flashVersion:	'7',	// required flash version
	expressInstaller: null,	// src for express installer

	// default flash video and mp3 player (@see: http://jeroenwijering.com/?item=Flash_Media_Player)
	flvPlayer:	 'mediaplayer.swf',
	mp3Player:	 'mediaplayer.swf',

	// @see http://msdn2.microsoft.com/en-us/library/bb412401.aspx
	silverlight: {
		inplaceInstallPrompt: 'true', // display in-place install prompt?
		isWindowless:		  'true', // windowless mode (false for wrapping markup)
		framerate:			  '24',	  // maximum framerate
		version:			  '0.9',  // Silverlight version
		onError:			  null,	  // onError callback
		onLoad:			      null,   // onLoad callback
		initParams:			  null,	  // object init params
		userContext:		  null	  // callback arg passed to the load callback
	}
};

// Media Players; think twice before overriding
$.fn.media.defaults.players = {
	flash: {
		name:		 'flash',
		title:		 'Flash',
		types:		 'flv,mp3,swf',
		mimetype:	 'application/x-shockwave-flash',
		pluginspage: 'http://www.adobe.com/go/getflashplayer',
		ieAttrs: {
			classid:  'clsid:d27cdb6e-ae6d-11cf-96b8-444553540000',
			type:	  'application/x-oleobject',
			codebase: 'http://fpdownload.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=' + $.fn.media.defaults.flashVersion
		}
	},
	quicktime: {
		name:		 'quicktime',
		title:		 'QuickTime',
		mimetype:	 'video/quicktime',
		pluginspage: 'http://www.apple.com/quicktime/download/',
		types:		 'aif,aiff,aac,au,bmp,gsm,mov,mid,midi,mpg,mpeg,mp4,m4a,psd,qt,qtif,qif,qti,snd,tif,tiff,wav,3g2,3gp',
		ieAttrs: {
			classid:  'clsid:02BF25D5-8C17-4B23-BC80-D3488ABDDC6B',
			codebase: 'http://www.apple.com/qtactivex/qtplugin.cab'
		}
	},
	realplayer: {
		name:		  'real',
		title:		  'RealPlayer',
		types:		  'ra,ram,rm,rpm,rv,smi,smil',
		mimetype:	  'audio/x-pn-realaudio-plugin',
		pluginspage:  'http://www.real.com/player/',
		autoplayAttr: 'autostart',
		ieAttrs: {
			classid: 'clsid:CFCDAA03-8BE4-11cf-B84B-0020AFBBCCFA'
		}
	},
	winmedia: {
		name:		  'winmedia',
		title:		  'Windows Media',
		types:		  'asx,asf,avi,wma,wmv',
		mimetype:	  $.browser.mozilla && isFirefoxWMPPluginInstalled() ? 'application/x-ms-wmp' : 'application/x-mplayer2',
		pluginspage:  'http://www.microsoft.com/Windows/MediaPlayer/',
		autoplayAttr: 'autostart',
		oUrl:		  'url',
		ieAttrs: {
			classid:  'clsid:6BF52A52-394A-11d3-B153-00C04F79FAA6',
			type:	  'application/x-oleobject'
		}
	},
	// special cases
	iframe: {
		name:  'iframe',
		types: 'html,pdf'
	},
	silverlight: {
		name:  'silverlight',
		types: 'xaml'
	}
};

//
//	everything below here is private
//


// detection script for FF WMP plugin (http://www.therossman.org/experiments/wmp_play.html)
// (hat tip to Mark Ross for this script)
function isFirefoxWMPPluginInstalled() {
	var plugs = navigator.plugins;
	for (var i = 0; i < plugs.length; i++) {
		var plugin = plugs[i];
		if (plugin['filename'] == 'np-mswmp.dll')
			return true;
	}
	return false;
}

var counter = 1;

for (var player in $.fn.media.defaults.players) {
	var types = $.fn.media.defaults.players[player].types;
	$.each(types.split(','), function(i,o) {
		if (isDigit(o[0])) o = 'fn' + o;
		$.fn.media[o] = $.fn.media[player] = getGenerator(player);
		$.fn.media[o+'_player'] = $.fn.media.defaults.players[player];
	});
};

function getTypesRegExp() {
	var types = '';
	for (var player in $.fn.media.defaults.players) {
		if (types.length) types += ',';
		types += $.fn.media.defaults.players[player].types;
	};
	return new RegExp('\\.(' + types.replace(/,/ig,'|') + ')\\b');
};

function getGenerator(player) {
	return function(el, options) {
		return generate(el, options, player);
	};
};

function isDigit(c) {
	return '0123456789'.indexOf(c) > -1;
};

// flatten all possible options: global defaults, meta, option obj
function getSettings(el, options) {
	options = options || {};
	var $el = $(el);
	var cls = el.className || '';
	// support metadata plugin (v1.0 and v2.0)
	var meta = $.metadata ? $el.metadata() : $.meta ? $el.data() : {};
	meta = meta || {};
	var w = meta.width	 || parseInt(((cls.match(/w:(\d+)/)||[])[1]||0));
	var h = meta.height || parseInt(((cls.match(/h:(\d+)/)||[])[1]||0));

	if (w) meta.width	= w;
	if (h) meta.height = h;
	if (cls) meta.cls = cls;

	var a = $.fn.media.defaults;
	var b = options;
	var c = meta;

	var p = { params: { bgColor: options.bgColor || $.fn.media.defaults.bgColor } };
	var opts = $.extend({}, a, b, c);
	$.each(['attrs','params','flashvars','silverlight'], function(i,o) {
		opts[o] = $.extend({}, p[o] || {}, a[o] || {}, b[o] || {}, c[o] || {});
	});

	if (typeof opts.caption == 'undefined') opts.caption = $el.text();

	// make sure we have a source!
	opts.src = opts.src || $el.attr('href') || $el.attr('src') || 'unknown';
	return opts;
};

//
//	Flash Player
//

// generate flash using SWFObject library if possible
$.fn.media.swf = function(el, opts) {
	if (!window.SWFObject && !window.swfobject) {
		// roll our own
		if (opts.flashvars) {
			var a = [];
			for (var f in opts.flashvars)
				a.push(f + '=' + opts.flashvars[f]);
			if (!opts.params) opts.params = {};
			opts.params.flashvars = a.join('&');
		}
		return generate(el, opts, 'flash');
	}

	var id = el.id ? (' id="'+el.id+'"') : '';
	var cls = opts.cls ? (' class="' + opts.cls + '"') : '';
	var $div = $('<div' + id + cls + '>');

	// swfobject v2+
	if (window.swfobject) {
		$(el).after($div).appendTo($div);
		if (!el.id) el.id = 'movie_player_' + counter++;

		// replace el with swfobject content
		swfobject.embedSWF(opts.src, el.id, opts.width, opts.height, opts.flashVersion,
			opts.expressInstaller, opts.flashvars, opts.params, opts.attrs);
	}
	// swfobject < v2
	else {
		$(el).after($div).remove();
		var so = new SWFObject(opts.src, 'movie_player_' + counter++, opts.width, opts.height, opts.flashVersion, opts.bgColor);
		if (opts.expressInstaller) so.useExpressInstall(opts.expressInstaller);

		for (var p in opts.params)
			if (p != 'bgColor') so.addParam(p, opts.params[p]);
		for (var f in opts.flashvars)
			so.addVariable(f, opts.flashvars[f]);
		so.write($div[0]);
	}

	if (opts.caption) $('<div>').appendTo($div).html(opts.caption);
	return $div;
};

// map flv and mp3 files to the swf player by default
$.fn.media.flv = $.fn.media.mp3 = function(el, opts) {
	var src = opts.src;
	var player = /\.mp3\b/i.test(src) ? $.fn.media.defaults.mp3Player : $.fn.media.defaults.flvPlayer;
	var key = opts.flvKeyName;
	src = encodeURIComponent(src);
	opts.src = player;
	opts.src = opts.src + '?'+key+'=' + (src);
	var srcObj = {};
	srcObj[key] = src;
	opts.flashvars = $.extend({}, srcObj, opts.flashvars );
	return $.fn.media.swf(el, opts);
};

//
//	Silverlight
//
$.fn.media.xaml = function(el, opts) {
	if (!window.Sys || !window.Sys.Silverlight) {
		if ($.fn.media.xaml.warning) return;
		$.fn.media.xaml.warning = 1;
		alert('You must include the Silverlight.js script.');
		return;
	}

	var props = {
		width: opts.width,
		height: opts.height,
		background: opts.bgColor,
		inplaceInstallPrompt: opts.silverlight.inplaceInstallPrompt,
		isWindowless: opts.silverlight.isWindowless,
		framerate: opts.silverlight.framerate,
		version: opts.silverlight.version
	};
	var events = {
		onError: opts.silverlight.onError,
		onLoad: opts.silverlight.onLoad
	};

	var id1 = el.id ? (' id="'+el.id+'"') : '';
	var id2 = opts.id || 'AG' + counter++;
	// convert element to div
	var cls = opts.cls ? (' class="' + opts.cls + '"') : '';
	var $div = $('<div' + id1 + cls + '>');
	$(el).after($div).remove();

	Sys.Silverlight.createObjectEx({
		source: opts.src,
		initParams: opts.silverlight.initParams,
		userContext: opts.silverlight.userContext,
		id: id2,
		parentElement: $div[0],
		properties: props,
		events: events
	});

	if (opts.caption) $('<div>').appendTo($div).html(opts.caption);
	return $div;
};

//
// generate object/embed markup
//
function generate(el, opts, player) {
	var $el = $(el);
	var o = $.fn.media.defaults.players[player];

	if (player == 'iframe') {
		var o = $('<iframe' + ' width="' + opts.width + '" height="' + opts.height + '" >');
		o.attr('src', opts.src);
		o.css('backgroundColor', o.bgColor);
	}
	else if ($.browser.msie) {
		var a = ['<object width="' + opts.width + '" height="' + opts.height + '" '];
		for (var key in opts.attrs)
			a.push(key + '="'+opts.attrs[key]+'" ');
		for (var key in o.ieAttrs || {}) {
			var v = o.ieAttrs[key];
			if (key == 'codebase' && window.location.protocol == 'https:')
				v = v.replace('http','https');
			a.push(key + '="'+v+'" ');
		}
		a.push('></ob'+'ject'+'>');
		var p = ['<param name="' + (o.oUrl || 'src') +'" value="' + opts.src + '">'];
		for (var key in opts.params)
			p.push('<param name="'+ key +'" value="' + opts.params[key] + '">');
		var o = document.createElement(a.join(''));
		for (var i=0; i < p.length; i++)
			o.appendChild(document.createElement(p[i]));
	}
	else if (o.standards) {
		// Rewritten to be standards compliant by Richard Connamacher
		var a = ['<object type="' + o.mimetype +'" width="' + opts.width + '" height="' + opts.height +'"'];
		if (opts.src) a.push(' data="' + opts.src + '" ');
		a.push('>');
		a.push('<param name="' + (o.oUrl || 'src') +'" value="' + opts.src + '">');
		for (var key in opts.params) {
			if (key == 'wmode' && player != 'flash') // FF3/Quicktime borks on wmode
				continue;
			a.push('<param name="'+ key +'" value="' + opts.params[key] + '">');
		}
		// Alternate HTML
		a.push('<div><p><strong>'+o.title+' Required</strong></p><p>'+o.title+' is required to view this media. <a href="'+o.pluginspage+'">Download Here</a>.</p></div>');
		a.push('</ob'+'ject'+'>');
	}
	 else {
	        var a = ['<embed width="' + opts.width + '" height="' + opts.height + '" style="display:block"'];
	        if (opts.src) a.push(' src="' + opts.src + '" ');
	        for (var key in opts.attrs)
	            a.push(key + '="'+opts.attrs[key]+'" ');
	        for (var key in o.eAttrs || {})
	            a.push(key + '="'+o.eAttrs[key]+'" ');
	        for (var key in opts.params) {
	            if (key == 'wmode' && player != 'flash') // FF3/Quicktime borks on wmode
	            	continue;
	            a.push(key + '="'+opts.params[key]+'" ');
	        }
	        a.push('></em'+'bed'+'>');
	    }
	// convert element to div
	var id = el.id ? (' id="'+el.id+'"') : '';
	var cls = opts.cls ? (' class="' + opts.cls + '"') : '';
	var $div = $('<div' + id + cls + '>');
	$el.after($div).remove();
	($.browser.msie || player == 'iframe') ? $div.append(o) : $div.html(a.join(''));
	if (opts.caption) $('<div>').appendTo($div).html(opts.caption);
	return $div;
};

})(jQuery);


/******* Media Plugin END ********/

/******* Text Box Hints START ********/
(function ($) {
	$.fn.hint = function (blurClass) {
	    if (!blurClass) blurClass = 'blur';
	    return this.each(function () {
	        var $input = $(this),
	            title = $input.attr('title'),
	            $form = $(this.form),
	            $win = $(window);
	        function remove() {
	            if (this.value === title && $input.hasClass(blurClass)) {
	                $input.val('').removeClass(blurClass);
	            }
	        }
	        // only apply logic if the element has the attribute
	        if (title) {
	            // on blur, set value to title attr if text is blank
	            $input.blur(function () {
	                if (this.value === '') {
	                    $input.val(title).addClass(blurClass);
	                }
	            }).focus(remove).blur(); // now change all inputs to title
	            // clear the pre-defined text when form is submitted
	            $form.submit(remove);
	            $win.unload(remove); // handles Firefox's autocomplete
	        }
	    });
	};
})(jQuery);
$(function(){
	// elements with class 'blur'
	$('.blur').hint();
});
/******* Text Box Hints END ********/

/******* JQUERY COOKIE ********/
jQuery.cookie = function(name, value, options) {
    if (typeof value != 'undefined') { // name and value given, set cookie
        options = options || {};
        if (value === null) {
            value = '';
            options.expires = -1;
        }
        var expires = '';
        if (options.expires && (typeof options.expires == 'number' || options.expires.toUTCString)) {
            var date;
            if (typeof options.expires == 'number') {
                date = new Date();
                date.setTime(date.getTime() + (options.expires * 24 * 60 * 60 * 1000));
            } else {
                date = options.expires;
            }
            expires = '; expires=' + date.toUTCString(); // use expires attribute, max-age is not supported by IE
        }
        var path = options.path ? '; path=' + (options.path) : '';
        var domain = options.domain ? '; domain=' + (options.domain) : '';
        var secure = options.secure ? '; secure' : '';
        document.cookie = [name, '=', encodeURIComponent(value), expires, path, domain, secure].join('');
    } else { // only name given, get cookie
        var cookieValue = null;
        if (document.cookie && document.cookie != '') {
            var cookies = document.cookie.split(';');
            for (var i = 0; i < cookies.length; i++) {
                var cookie = jQuery.trim(cookies[i]);
                if (cookie.substring(0, name.length + 1) == (name + '=')) {
                    cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
                    break;
                }
            }
        }
        return cookieValue;
    }
};
/******* End jquery cookie ********/

/******* Hovers START ********/
$(document).ready(function(){
    $('.myCity').hover(
	function () {
	    $(this).children('.removeCity').show();
	    $(this).children('.removeCity').click(function(){
		$(this).parent('.myCity').remove();
		return false;
	    });
        },
        function () {
	    $(this).children('.removeCity').hide();
        }
    );

    $('.resortsRow').hover(
	function () {
	    $(this).children('.resortName').addClass('resortNameHover');
        },
        function () {
	    $(this).children('.resortName').removeClass('resortNameHover');
        }
    );

    $('.searchTopButton').hover(
	function () {
	    $(this).addClass('searchTopButtonHover');
        },
        function () {
	    $(this).removeClass('searchTopButtonHover');
        }
    );
});
/******* Hovers Hover END ********/

/******* Hide Additional Information START ********/
$(document).ready(function(){
    let wfCurrentShort;
    wfCurrentShort = $('.wfCurrentShort').height();
    function hideShow() {
        var wfArray = new Array();
        // Short values MUST be the same as in home.css
        wfArray['wfCurrent_short'] = 364; wfArray['wfCurrent_full'] = 734;
        wfArray['wfHourly_short'] = 341; wfArray['wfHourly_full'] = 920;
        wfArray['wfWeekend_short'] = 311; wfArray['wfWeekend_full'] = 1030;
        wfArray['wf5day_short'] = 330; wfArray['wf5day_full'] = 1041;
        wfArray['wf10day_short'] = 257; wfArray['wf10day_full'] = 1193;
        wfArray['wf10DetailsFullDay_short'] = 415; wfArray['wf10DetailsFullDay_full'] = 678;
        wfArray['wf10DetailsDay_short'] = 515; wfArray['wf10DetailsDay_full'] = 1110;
        wfArray['wfDetailsFullDay_short'] = 450; wfArray['wfDetailsFullDay_full'] = 744;
        wfArray['wfDetailsDay_short'] = 549; wfArray['wfDetailsDay_full'] = 1140;
        $('.wfHideDetails').click(function(){
			var currContent = $(this).prev().children().attr('id');
			var current_height;
			var text_value;
			if( $(this).hasClass('wfHideDetailsDown')) {
				if (currContent.indexOf("resort")>-1) {
					current_height = wfArray['wfCurrent_full'];
				} else {
					current_height = wfArray[currContent+'_full'];
				};
				$(this).removeClass('wfHideDetailsDown');
				text_value = $(this).text();
				$(this).text($(this).attr('rel') + ' ');
				$(this).attr('rel', text_value);
				$(this).append('<span class="arrow"></span>');
				$(this).find('span').css({
				 	transform: 'rotate(180deg)',
				 	transition: 'transform 0.5s'
				});
				//$(this).text('РЎРєСЂРёР№ РґРµС‚Р°Р№Р»Рё');
				$('#'+ currContent).animate( { height: current_height +'px' } , 900 , function(){
					$('#'+ currContent).css("overflow", "visible");
					$.cookie('showdetails', '1', { expires: 730, path: '/' });
				});
			} else {
				if (currContent.indexOf("resort")>-1) { 
					current_height = wfArray['wfCurrent_short']; 
				} else { 
					current_height = wfArray[currContent+'_short'];
				};
				$(this).addClass('wfHideDetailsDown');
				text_value = $(this).text();
				$(this).text($(this).attr('rel') + ' ');
				$(this).attr('rel', text_value);
				$(this).append('<span class="arrow"></span>');
				
				//$(this).text('РџРѕРєР°Р¶Рё РґРµС‚Р°Р№Р»Рё');
				$('#'+ currContent).animate( { height: current_height +'px' } , 900, function(){
					$('#'+ currContent).css("overflow", "hidden");
					$.cookie('showdetails', '0', { expires: 730, path: '/' });
				})
			}
			return false;
        });
        return false;
    }
    hideShow();
});
/******* Hide Additional Information END ********/


/******* Choose Region & Country START ********/
$(document).ready(function(){
    var cHandler = function() {
		$('.chooseRegionList').hide();
    };
    $('.selectedRegion').click(function(){
		$(this).bind('blur', cHandler);
		$('.chooseRegionList').toggle();
		//$(this).find('svg').toggleClass('rotate180', $('.chooseRegionList').is(':visible'));
		var selectedSvg = $(this).find('.selectArrow');
		var rotation = selectedSvg.attr('transform') === 'rotate(180)' ? 'rotate(0)' : 'rotate(180)';
    	selectedSvg.attr('transform', rotation);
		selectedSvg.attr('style', 'transition: transform 0.3s ease-in-out');
		setTimeout(function() {
			selectedSvg.attr('style', '');
		}, 300);
		return false;
    });
    $('.chooseRegionList li a').hover(
	function(){
	    $('.selectedRegion').unbind('blur', cHandler);
	},
	function(){
	    $('.selectedRegion').bind('blur', cHandler);
	}
    );
});
/******* Choose Region & Country END ********/

/******* By Hours Slide START ********/
$(document).ready(function(){

    var wfTpcPlay = 0;
    var currBHSNum = 0;
    var currentTpc = 'wfPrecipitation';
    var currentTpcTab = '#wfPrecipitation';

    var currBhs = 0;
    var currBhsId = 0;
	let wholeWidth = $('.wfTpc').width();

    $('.tpcTabs li a').click(function(){ //When any link is clicked
        clearInterval(wfTpcPlay);
        wfTpcPlay = 0;
		currBhsId = 1;
        $('.tpcTabs li').removeClass('selected'); // Remove active class from all links
        $(this).parent().parent('li').addClass('selected'); //Set clicked link class to active
        currentTpcTab = $(this).attr('href'); // Set variable currentTab to value of href attribute of clicked link
        $('.tpcBlock > .tabContent').hide(); // Hide all divs
        $(currentTpcTab).show(); // Show div with id equal to variable currentTab
		$(currentTpcTab).css('display', 'flex');
        currentTpc = currentTpcTab.replace('#', '');
		if(currentTpcTab!=='#wfTeraflu'){
			startSlideShow(Bhs);
		}
		let selector = currentTpcTab + ' ul li';
		let numOfLi = $(selector).length;
		let liWidth = wholeWidth / numOfLi;
		let halfLiWidth = liWidth / 2;
		function addBeforeElem() {
			var beforeElement = $("<div></div>");
			beforeElement.addClass("before-progressBar");
			beforeElement.css("width", halfLiWidth);
			$(".progressBarMiddle").append(beforeElement);
		}
		addBeforeElem();
		$(window).resize(function () {
			addBeforeElem();
			repositionPointerAfterResize(currentTpcTab)
		});
		repositionPointerAfterResize(currentTpcTab);
        return false;
    });

	/* Reposition city on the map when map size changes */
	let fixedMapWidth = 450;
	let fixedMapHeight = 300;
	let initialOffsetLeft, initialOffsetTop;

	function repositionPointerAfterResize(currentTpcTab) {
		const pointerElement = $(currentTpcTab + ' .wfTpcImgPointer');
		const mapContainer = $(currentTpcTab + ' .wfTpcImg');

		if (initialOffsetLeft === undefined || initialOffsetTop === undefined) {
			initialOffsetLeft = parseFloat(pointerElement.css('left')) || 0;
			initialOffsetTop = parseFloat(pointerElement.css('top')) || 0;
		}
		const originalWidth = fixedMapWidth;
		const originalHeight = fixedMapHeight;
	
		const newWidth = mapContainer.width();
		const newHeight = mapContainer.outerHeight();
	
		// Calculate the ratio between the new and original dimensions
		const widthRatio = newWidth / originalWidth;
		const heightRatio = newHeight / originalHeight;
	
		// Calculate the new left and top coordinates based on the ratio
		let newLeft = widthRatio * initialOffsetLeft;
		let newTop = heightRatio * initialOffsetTop;
	
		if (pointerElement.length) {
			pointerElement.css({ left: newLeft + 'px', top: newTop + 'px' });
		} else {
			console.error('Element with class "wfTpcImgPointer" not found.');
		}
	}
	function startSlideShow(Bhs) {
		
        $(currentTpcTab +' .wfTpcImg .loaderImg').replaceWith('<img src="'+ Bhs[currentTpc][currBHSNum]['img'] +'" width="450" height="300" />');
        /* Creating Progres Bar */
        $('.progressBar').remove();
        $('.wfTpcImg').after('<div class="progressBar">'
            +'<div class="progressBarMiddle">'
            +'<div class="progressBarInner"></div>'
            +'</div>'
            +'</div>'
            );

        /* Creating navigation */
        $(currentTpcTab +' ul').remove();
        var navBhs = '<ul>';
        $.each(Bhs[currentTpc], function(index, value){
            navBhs = navBhs + '<li><a href="#'+ value['id'] +'" id="'+ currentTpc + value['id'] +'" class="'+ (((value['id']) == 1)?'selected':'') +'" rel="'+ value['id'] +'">'+ value['hour'] +'</a>'+ ((value['day'])?'<span class="wfTpcFirst">'+ value['day'] +'</span>':'') +'</li>';
        });
        navBhs = navBhs + '</ul>';

        $(currentTpcTab +' .wfTpc').append(navBhs);
				
		function onHoverProgress(callbackFunc) {
			$(currentTpcTab +' .wfTpc ul li a').hover( // On Hover
            function() {
				let selector = currentTpcTab + ' ul li';
				let liWidth = $(selector).width();
				let halfLiWidth = liWidth / 2;
                if(wfTpcPlay > 0) {
                    $('.wfTpcPlay').removeClass('wfTpcPause');
                    clearInterval(wfTpcPlay);
                    wfTpcPlay = 0;
                }
                $(currentTpcTab +' .wfTpc ul li a').removeClass('selected');
                $(this).addClass('selected');
                var currentHour = $(this).attr('rel');
                currBhsId = parseInt(currentHour);
                currBhs = Bhs[currentTpc][currBhsId - 1]['img'];
                $(currentTpcTab +' .wfTpcImg img').attr({
                    src: currBhs
                });
                $('.progressBarInner').width((currBhsId - 1) * liWidth + halfLiWidth);
				if (typeof callbackFunc === 'function') {
					callbackFunc(currBhsId);
				  } else {
					console.error('callbackFunc is not a function');
				  }	
            });
		}
		onHoverProgress(function(currBhsId) {
			$(window).resize(function () {
				let selector = currentTpcTab + ' ul li';
				let liWidth = $(selector).width();
				let halfLiWidth = liWidth / 2;
				$('.progressBarInner').width((currBhsId - 1) * liWidth + halfLiWidth);
			});
		});
		
    } // end start slide show

    $('.wfTpcPrev').click(function() { // On Click Prev Button
            $('.progressBarRight').removeClass('progressBarHoverRight');
            if(wfTpcPlay > 0) {
                $('.wfTpcPlay').removeClass('wfTpcPause');
                clearInterval(wfTpcPlay);
                wfTpcPlay = 0;
            }
            currBhsId -= 1;
            if (currBhsId == 0) {
                currBhsId = Bhs[currentTpc].length;
            }
            currBhs = Bhs[currentTpc][currBhsId - 1]['img'];
            $(currentTpcTab +' .wfTpc ul li a').removeClass('selected');
            $('#'+ currentTpc + currBhsId).addClass('selected');
            $(currentTpcTab +' .wfTpcImg img').attr({
                src: currBhs
            });
            if(currBhsId == Bhs[currentTpc].length) {
                $('.progressBarRight').show();
            }
            $('.progressBarInner').width((currBhsId - 1) * 38);
            return false;
    });

    $('.wfTpcNext').click(function() { // On Click Next Button
            $('.progressBarRight').removeClass('progressBarHoverRight');
            if(wfTpcPlay > 0) {
                $('.wfTpcPlay').removeClass('wfTpcPause');
                clearInterval(wfTpcPlay);
                wfTpcPlay = 0;
            }
            currBhsId += 1;
            if (currBhsId == Bhs[currentTpc].length + 1) {
                currBhsId = 1;
            }
            currBhs = Bhs[currentTpc][currBhsId - 1]['img'];
            $(currentTpcTab +' .wfTpc ul li a').removeClass('selected');
            $('#'+ currentTpc + currBhsId).addClass('selected');
            $(currentTpcTab +' .wfTpcImg img').attr({
                src: currBhs
            });
            if(currBhsId == Bhs[currentTpc].length) {
                $('.progressBarRight').show();
            }
            $('.progressBarInner').width((currBhsId - 1) * 38);
            return false;
    });
	
    $('.wfTpcPlay').click(function() {
        if (wfTpcPlay > 0) {
            clearInterval(wfTpcPlay);
            wfTpcPlay = 0;
        } else {
            wfTpcPlay = window.setInterval(function(){
                $('.progressBarRight').removeClass('progressBarHoverRight');
                currBhsId += 1;
                if (currBhsId == Bhs[currentTpc].length + 1) {
                    currBhsId = 1;
                }
                currBhs = Bhs[currentTpc][currBhsId - 1]['img'];
                $(currentTpcTab +' .wfTpc ul li a').removeClass('selected');
                $('#'+ currentTpc + currBhsId).addClass('selected');
                $(currentTpcTab +' .wfTpcImg img').attr({
                    src: currBhs
                });
                if(currBhsId == Bhs[currentTpc].length) {
                    $('.progressBarRight').show();
                }
                $('.progressBarInner').width((currBhsId - 1) * 38);			
			}, 1500);
        }
        $(this).toggleClass('wfTpcPause');
        return false;
    });
 
	// Create a MutationObserver instance
	const observerImgWeather = new MutationObserver((mutations) => {
		mutations.forEach((mutation) => {
			if (mutation.target.classList.contains('has-branding')) {
			repositionPointerAfterResize(currentTpcTab);
			observerImgWeather.disconnect();
			}
		});
	});
	
	if (document.body instanceof Node) {
		const config = { attributes: true, attributeFilter: ['class'] };
		observerImgWeather.observe(document.body, config);
	}
	const timeoutDuration = 8000;
	const timeoutId = setTimeout(() => {
	  	observerImgWeather.disconnect();
	}, timeoutDuration);
	
	
});
/******* By Hours Slide END ********/

/* SEARCHING AUTOCOMPLETE */
$(document).ready(function(){
	function fnFormatResult(value, data, currentValue) {
		var reEscape = new RegExp("(\\/|\\.|\\*|\\+|\\?|\\||\\(|\\)|\\[|\\]|\\{|\\}|\\\\)","g");
		var pattern = '(' + currentValue.replace(reEscape, '\\$1') + ')';
		var urldata = data.split('||');
		var values = value.split(', ');
		return '<img src="//m.netinfo.bg/sinoptik/images/flags/'+urldata[1]+'.gif" width="16" height="11" />'+'<b>'+values[0]+'</b>'+value.replace(values[0], '');
		//return '<img src="//m.netinfo.bg/sinoptik/images/flags/'+urldata[1]+'.gif" width="16" height="11" />'+value.replace(new RegExp(pattern, 'gi'), '<strong>$1<\/strong>');
	}
    var ac_options = {
      serviceUrl: '/search/autocomplete/',
      minChars: 2,
      width: 289,
	  maxHeight:304,
      deferRequestBy: 40,
	  fnFormatResult: fnFormatResult,
	  noCache: false,
      onSelect: function(value, data){
		var link_prefix = ($('#inMap').is(':checked')) ? '/map/' : '/';
		var urldata = data.split('||');
		window.location=link_prefix+urldata[0]+'?search';
	  },
      noCache: false
    };
   var searchAutoComplete = $('#searchField').autocomplete(ac_options);
});

$(document).ready(function() {
    // Select all the temperature elements
    $('.wfCurrentTemp, .winterResortCityTemp').each(function() {
        var $temperatureElement = $(this);
        var temperatureText = $temperatureElement.text();
        var number = temperatureText.match(/-?\b\d+\b/);
        temperatureText = temperatureText.replace(number, '<span class="number">' + number + '</span>');
        $temperatureElement.html(temperatureText);

        var $numberElement = $temperatureElement.find('.number');
        $numberElement.css({
            'font-size': '54px',
            'font-family': 'Roboto Bold',
            'vertical-align': 'text-top'
        });
    });
});

$(document).ready(function(){
	let slideWidth;
	let totalLinks;
	let linksPerSlide;
	let currentPosition;
	$('.wfWeekendMain .next, .wfWeekendMain .prev, .wf5dayMain .prev, .wf5dayMain .next').hide();
	let dayPeriodSlider = $('.wf14dayRightContent').find('.slider');
	
	function getNumberFromURL() {
		let url = window.location.href;
		let matches = url.match(/\/(\d+)$/);
		if (matches) {
			return parseInt(matches[1]);
		}
		return null;
	}

	function moveSliderToSlide(slideIndex) {
		slideWidth = $('.fourteenday-container').width();
		if(slideIndex == 2) {
			dayPeriodSlider.css('left', -slideWidth);
		}
	}

	var numberFromURL = getNumberFromURL();

	if (numberFromURL !== null) {
		let slideIndex = Math.ceil(numberFromURL / 7); // Assuming 7 columns per slide
		moveSliderToSlide(slideIndex);
	}

    function updateColumnWidths() {
		slideWidth = $('.fourteenday-container').width();
		totalLinks = $('.fourteenday-container .slider .slide a').length;
		if (totalLinks < 7) {
			linksPerSlide = totalLinks;
			return;
		} else {
			linksPerSlide = Math.ceil(totalLinks / 2); // Divide links into two slides
		}
		let calculatedWidth = slideWidth * (totalLinks / linksPerSlide);
		$('.fourteenday-container .slider').width(calculatedWidth);
		currentPosition = parseInt($('.fourteenday-container .slider').css('left'));
		
		if(currentPosition !== 0) {
			currentPosition = calculatedWidth / 2;
			$('.fourteenday-container .next').hide();
			$('.fourteenday-container .prev').show();
			$('.fourteenday-container .slider').css('left', -currentPosition);
		} else {
			$('.fourteenday-container .next').show();
			$('.fourteenday-container .prev').hide();
		}
	}
	// Initial setup
	updateColumnWidths();
	// Create a MutationObserver instance
	const observerFourteenday = new MutationObserver((mutations) => {
		mutations.forEach((mutation) => {
			if (mutation.target.classList.contains('has-branding')) {
			updateColumnWidths();
			observerFourteenday.disconnect();
			}
		});
	});
	
	if (document.body instanceof Node) {
		const config = { attributes: true, attributeFilter: ['class'] };
		observerFourteenday.observe(document.body, config);
	}
	const timeoutDuration = 8000;
	const timeoutId = setTimeout(() => {
	  	observerFourteenday.disconnect();
  		console.log('Observer disconnected after timeout.');
	}, timeoutDuration);
	
	$(window).resize(function () {
		updateColumnWidths();
	});
	
	$('.fourteenday-container .prev').click(function() {
        currentPosition = parseInt($('.fourteenday-container .slider').css('left'));
        if (currentPosition < 0) {
            $('.fourteenday-container .slider').animate({ left: currentPosition + slideWidth }, 100);
			$('.fourteenday-container .next').show();
			$('.fourteenday-container .prev').hide();
			//localStorage.setItem('sliderPosition', currentPosition + slideWidth);
        }
		//currentPosition = localStorage.getItem('sliderPosition');
    });
	
	$('.fourteenday-container .next').click(function() {
        currentPosition = parseInt($('.fourteenday-container .slider').css('left'));
		if (currentPosition == 0) {
            $('.slider').animate({ left: currentPosition - slideWidth }, 100);
			$('.fourteenday-container .prev').show();
			$('.fourteenday-container .next').hide();
			//localStorage.setItem('sliderPosition', currentPosition - slideWidth);
        }	
    });
	
});
let sliderMinutes;
let sliderHours;
$(document).ready(function() {
	
    $('#tab2').hide();
	sliderHours = new Slider('wfTabHourlyContentSlide', 'wfSlideNext', 'wfSlidePrev', 'wfByHourGraphBlock');
	sliderMinutes = new Slider('wfTabHourlyContentSlide2', 'wfSlideNext2', 'wfSlidePrev2', 'wfByHourGraphBlock');
	const observerTabSliders = new MutationObserver((mutations) => {
		mutations.forEach((mutation) => {
			if (mutation.target.classList.contains('has-branding')) {
			sliderHours.runSlide();
			sliderMinutes.runSlide();
			observerTabSliders.disconnect();
			}
		});
	});
	if (document.body instanceof Node) {
		const config = { attributes: true, attributeFilter: ['class'] };
		observerTabSliders.observe(document.body, config);
	}
	const timeoutDuration = 8000;
	const timeoutId = setTimeout(() => {
	  	observerTabSliders.disconnect();
	}, timeoutDuration);
});

function showTab(tabId, div) {
	$('#tabMenu div').removeClass('active-tab');
	$(div).addClass('active-tab');
	// Hide all tabs
	$('.hourly-tab').fadeOut(100);
	//console.log("Working" + ' ' + tabId)

	// Show the selected tab with fadeIn effect
	$('#' + tabId).fadeIn(300);
	if (tabId === 'tab2') {
		sliderMinutes.destroy();
		sliderMinutes.runSlide();	
	} else if(tabId === 'tab1') {
		sliderHours.destroy();
		sliderHours.runSlide();	
	}
}

$(document).ready(function() {
	function initMap() {
		const map = new google.maps.Map(document.getElementById("map"), {
		  zoom: 4,
		  center: { lat: -33, lng: 151 },
		  zoomControl: false,
		  scaleControl: true,
		});
	  }
	  
	  window.initMap = initMap;
});

$(document).ready(function() {
    $('.mvr-messages-alertmeteoalarm li').each(function() {
        var backgroundColor = $(this).css('background-color');

        // Check if the background color of the alert message is yellow
        if (backgroundColor === 'rgb(255, 255, 0)') {
			$(this).css('background-color', '#FEC74B')
            $(this).find('.text').css('color', '#454545');
			$(this).find('span svg').css('stroke', '#454545');
			$(this).find('h3 svg').css('fill', '#454545');
        }
		$(this).on('click', function() {
			$(this).toggleClass('expanded');
			let $svg = $(this).find('span');
			$svg.toggleClass('rotated');
		});
    });
});
$(document).ready(function() {
	let bannerBigSize = false;
	
	const intervalId = setInterval(() => {
		let bannerId = $('#w2g-slot2-desktop');
		let bannerOuter = $('.nav_banner');
		setTimeout(function() {
			if ($(bannerId).is(':hidden')) {
				bannerOuter.css({
					height: "0",
					minHeight: "0",
					overflow: "hidden"
				});
				clearInterval(intervalId);
				return;
			}
		}, 5000);
		if (bannerId.hasClass('w2g-slot2-desktop-loaded')) {
			if(bannerBigSize == true) {
				bannerOuter.css({
					height: "250px",
					width: "970px",
					//backgroundColor: "transparent"
				});
				
				bannerOuter.find('div[id^="div-gpt-ad"]').css({
					position: "relative",
    				top: "50%",
    				transform: "translateY(-50%)"
				});
				clearInterval(intervalId);
			}
			if(bannerId.height() == 250) {
				bannerBigSize = true;
			}
		}
	}, 100);
});

class Slider {
    constructor(sliderContainerId, nextButtonClass, prevButtonClass, graphicClass) {
        this.slideIndex = 0;
        this.isAnimating = false;
        this.slider = $(`#${sliderContainerId}`);
        this.lastElemClass = graphicClass;
        this.slide = this.slider.find('.wfTabHourlyContentSlide2');
        this.slideCount = this.slide.length;
        this.slideWidthArray = [];
        this.nextButton = $(`.${nextButtonClass}`);
        this.prevButton = $(`.${prevButtonClass}`);
        this.numOfElem = this.slide.eq(0).find($('.wfByHour')).length;
        this.initialize();
        this.bindEvents();
    }

    initialize() {
        this.runSlide();
    }
    
    runSlide() {
        let sliderWidth = this.slider.outerWidth();
        let elemWidth = Math.round(sliderWidth / this.numOfElem);
        let maxHeight = 0;
        let slideHeight = 0;
        this.isAnimating = false;
        
        this.slide.each((index, element) => {
            let children = $(element).children();
            let childrenToAdjust = children;
            if (children.last().hasClass(this.lastElemClass)) {
                childrenToAdjust = children.slice(0, -1);
            }
            let numOfElements = childrenToAdjust.length;
            let slideWidth = Math.round(elemWidth * numOfElements);
            $(element).width(slideWidth);
            this.slideWidthArray[index] = slideWidth;

            $(element).css('display', 'flex');
            slideHeight = $(element).outerHeight();
            
            $(element).css('display', 'none');
            if (slideHeight > maxHeight) {
                maxHeight = slideHeight;
            }
            childrenToAdjust.css('width', elemWidth);
        });
        
        // If the last slide is narrower
        if(this.slideIndex === this.slideCount - 1) {
            if(this.slideWidthArray[this.slideWidthArray.length - 1] !== this.slideWidthArray[0]) {
                this.slide.eq(this.slideIndex - 1).css('display', 'flex');
                this.slide.eq(this.slideIndex - 1).css('left', -this.slideWidthArray[this.slideIndex]);
                this.slide.eq(this.slideIndex).css('left', this.slideWidthArray[this.slideIndex]);
				if(this.slideCount == 2) {
                    this.prevButton.show();
                }
            } else if(this.slideIndex === this.slideCount - 1 && this.slideWidthArray[this.slideWidthArray.length - 1] === this.slideWidthArray[0]) {
                this.slide.eq(this.slideIndex).css('left', '0px');
                this.slide.eq(this.slideIndex - 1).css('left', -this.slideWidthArray[this.slideIndex]);
            }
            this.nextButton.hide();
        } else if(this.slideIndex > 0) {
             
            this.slide.eq(this.slideIndex - 1).css('left', -this.slideWidthArray[this.slideIndex]);
            this.slide.eq(this.slideIndex + 1).css('left', this.slideWidthArray[this.slideIndex]);
            
            this.prevButton.show();
            this.nextButton.show();
        } else {
            this.slide.eq(this.slideIndex).css('left', '0px');
            this.slide.eq(this.slideIndex + 1).css('left', this.slideWidthArray[this.slideIndex]);
            this.nextButton.show();
            this.prevButton.hide();
        }
        this.slide.eq(this.slideIndex).css('display', 'flex');
        this.slider.height(maxHeight);
        
    }

    controlNext() {
        this.slide.eq(this.slideIndex).css('display', 'flex');
        this.slide.eq(this.slideIndex).animate({ left: '-=' + this.slideWidthArray[this.slideIndex] }, {
            duration: 500,
            easing: 'linear'
        });
        this.slide.eq(this.slideIndex - 1).animate({ left: '-=' + this.slideWidthArray[this.slideIndex] }, {
            duration: 500,
            easing: 'linear',
            complete: () => this.runSlide()
        });         
    }
    controlPrev() {
        if(this.slideIndex === this.slideCount - 2 && this.slideWidthArray[this.slideWidthArray.length - 1] !== this.slideWidthArray[0]) {
            this.slide.eq(this.slideIndex + 1).css('display', 'flex');
            this.slide.eq(this.slideIndex).animate({ left: '+=' + this.slideWidthArray[this.slideIndex + 1] }, {
                duration: 500,
                easing: 'linear'
            });
            this.slide.eq(this.slideIndex + 1).animate({ left: '+=' + this.slideWidthArray[this.slideIndex + 1] }, {
                duration: 500,
                easing: 'linear',
                complete: () => this.runSlide()
            });
        } else {
            this.slide.eq(this.slideIndex).animate({ left: '+=' + this.slideWidthArray[this.slideIndex] }, {
                duration: 500,
                easing: 'linear'
            });
            this.slide.eq(this.slideIndex + 1).animate({ left: '+=' + this.slideWidthArray[this.slideIndex] }, {
                duration: 500,
                easing: 'linear',
                complete: () => this.runSlide()
            });
        }
        this.slide.eq(this.slideIndex).css('display', 'flex');
    }     
    bindEvents() {
        const self = this;

        this.nextButton.click(function () {
            if (!self.isAnimating && self.slideIndex < self.slideCount - 1) {
                self.slideIndex += 1;
                self.controlNext();
                self.isAnimating = true;
            }
        });

        this.prevButton.click(function () {
            if (!self.isAnimating && self.slideIndex > 0) {
                self.slideIndex -= 1;
                self.controlPrev();
                self.isAnimating = true;
            }
        });

        $(window).resize(function () {
            self.runSlide();
        });
    }
	destroy() {
		this.slideIndex = 0;
        this.slide.css({
			'display': '',
			'left': ''
		});
        this.runSlide();
    }
}
function rainSnowAnim() {
	const start = sas_target.indexOf('weathertype=') + 'weathertype='.length;
	const end = sas_target.indexOf(';', start);
	const weathertype = sas_target.substring(start, end);
	const matchRain = weathertype.match(/\brain\b/i);
	const matchLightRain = sas_target.match(/\blight\s*rain\b/i);
	const lightRain = matchLightRain ? matchLightRain[0] : null;
	const rain = matchRain ? matchRain[0] : null;
	const matchShowers = weathertype.match(/\bshowers\b/i);
	const showers = matchShowers ? matchShowers[0] : null;
	const matchSnow = weathertype.match(/\bsnow\b/i);
	const snow = matchSnow ? matchSnow[0] : null;
	
	
	const canvas = document.getElementById('rainCanvas');
        //console.log('canvas: '); console.log(canvas);
        if (typeof(canvas) == 'undefined' || canvas == null)
        {
          return false;
        }
	const ctx = canvas.getContext('2d');
	let dropLength = 35;
	let dropWidth = 1;
	let speedDrops = 3 + Math.random() * 4;
	let botSpace = 140;
	let dropCount = 75;
	if(snow) {
		dropLength = 2;
		dropWidth = 2;
		speedDrops = 1 + Math.random() * 3;
		botSpace = 10;
	}
	if(lightRain) {
		dropCount = 20;
	}
	
	canvas.width = canvas.offsetWidth;
	canvas.height = 280;
	
	// Define raindrop object
	function Raindrop(x, y, speedDrops) {
		this.x = x;
		this.y = y;
		this.speedDrops = speedDrops;
		this.update = function() {
			this.y += this.speedDrops;
			if (this.y > canvas.height - Math.random() * botSpace) {
			
			this.splash();
			
			this.y = 0;
			
			}
		};
		this.draw = function() {
			
			// Create a linear gradient
			const gradient = ctx.createLinearGradient(this.x, this.y, this.x, this.y + 40);
			gradient.addColorStop(0, 'rgba(255,255,255,0)'); // Start color with opacity
			gradient.addColorStop(1, 'rgba(255,255,255,0.3)');   // End color with no opacity
			ctx.beginPath();
			// Set the stroke style to the gradient
			if(rain || showers && !snow) {
				ctx.strokeStyle = gradient;
			} else if(snow) {
				ctx.arc(this.x, this.y, dropWidth / 2, 0, Math.PI * 2);
				ctx.strokeStyle = 'rgba(255,255,255,0.3)';
			}
		
		
			
			ctx.lineWidth = dropWidth;
			ctx.moveTo(this.x, this.y);
			ctx.lineTo(this.x, this.y + dropLength);
			ctx.stroke();
		};
		this.splash = function() {
		const gradient = ctx.createLinearGradient(this.x, this.y, this.x, this.y + 40);
		gradient.addColorStop(0, 'rgba(255,255,255,0)'); // Start color with opacity
		gradient.addColorStop(1, 'rgba(255,255,255,0.2)');   // End color with no opacity
		let posX;
		let posY;
		posX = this.x;
		posY = this.y + dropLength;
		// Set splash color and width
		ctx.strokeStyle = gradient;
		ctx.lineWidth = 1;
		
		// Calculate the angles for the lines (in radians)
		const angle1 = -Math.PI / 20; // 45 degrees
		const angle2 = -19 * Math.PI / 20; // -45 degrees
		
		let length1 = 0;
		let length2 = 0;
		
		// Define animation speed (higher values mean faster animation)
		const animationSpeed = 0.4; // Adjust as needed
	
		// Define animation function
		const animateLines = () => {
			// Increment the length of the lines
			length1 += animationSpeed;
			length2 += animationSpeed;
			
			// Draw the lines
			ctx.beginPath();
			ctx.moveTo(posX, posY);
			ctx.lineTo(posX + length1 * Math.cos(angle1), posY + length1 * Math.sin(angle1));
			ctx.stroke();
			
			ctx.beginPath();
			ctx.moveTo(posX, posY);
			ctx.lineTo(posX + length2 * Math.cos(angle2), posY + length2 * Math.sin(angle2));
			ctx.stroke();
			
			// Check if lines have reached full length
			if (length1 < 10 || length2 < 10) {
				// Continue animation
				requestAnimationFrame(animateLines);
			}
		};
	// Start the animation
		if(rain || showers && !snow) {
			animateLines();
		}
		};
	}
	// Create an array to store raindrops
	const raindrops = [];
	
	// Initialize raindrops
	for (let i = 0; i < dropCount; i++) {
		const x = Math.random() * canvas.width;
		const y = Math.random() * canvas.height;
		//const speed = 4 + Math.random() * 8; // Random speed between 2 and 6 pixels per frame
		raindrops.push(new Raindrop(x, y, speedDrops));
	}
	// Animation loop
	function animate() {
		requestAnimationFrame(animate);
		ctx.clearRect(0, 0, canvas.width, canvas.height);
	
		// Update and draw raindrops
		raindrops.forEach(raindrop => {
			raindrop.update();
			raindrop.draw();
		});
	}
	
	if(rain || snow || showers) {
		animate();
	}
  }
  $(document).ready(function() {
	rainSnowAnim();
  });


  window.addEventListener('load', function () {

	function applyTransformation() {
	  const brandingDiv = document.getElementById('div-gpt-ad-1553517775994-0');
	  if (brandingDiv) {
		if (document.body.classList.contains('has-branding') && window.innerWidth <= 1599) {
		  brandingDiv.style.transform = 'scale(0.75)';
		} else {
		  brandingDiv.style.transform = 'scale(1)'; // Reset scaling if conditions aren't met
		}
	  }
	}
  
	// MutationObserver to detect class changes on the body
	const observer = new MutationObserver(() => {
	  applyTransformation(); // Run when a class change occurs
	});
  
	observer.observe(document.body, { attributes: true, attributeFilter: ['class'] });
  
	// Call applyTransformation initially to check the current state
	applyTransformation();
  
	// Listen for window resize to re-check conditions
	window.addEventListener('resize', applyTransformation);
  });
// To be removed after Euro 2024 campaign
window.addEventListener('load', function() {
    let euroImages = document.getElementsByClassName('euro-img');
    let thirdImage = document.querySelector('.dsk-img');

    function setThirdImageHeight() {
        if (euroImages.length > 0 && thirdImage) {
            let firstImageHeight = euroImages[0].height;
            console.log("Height of the first image:", firstImageHeight);
            thirdImage.style.height = firstImageHeight + 'px';
            console.log("Height set to the third image:", firstImageHeight);
        } else {
            console.log("No elements with class 'euro-img' found.");
        }
    }

    // Call the function when the page loads and on screen resize
    window.addEventListener('resize', setThirdImageHeight);
    //setThirdImageHeight(); // Call the function initially
});

window.addEventListener('load', function () {
	const img = document.querySelector(".wfCurrentImg");
	const content = document.querySelector(".wfCurrentContent");
	const windWrapper = document.querySelector(".wfCurrentWindWrapper");

	function applyTheme() {
	const src = img?.getAttribute("src") || "";

	if (src.includes("/d") && content && windWrapper) {
		// Day theme
		content.style.backgroundColor = "#5EA1E7";
		windWrapper.style.backgroundColor = "#4E96DF";
	} else if (src.includes("/n") && content && windWrapper) {
		// Night theme
		content.style.backgroundColor = "#304779";
		windWrapper.style.backgroundColor = "#263f6f";
	}
	}

	// Run once on load
	applyTheme();

	// Watch for changes to the image src
	if (img) {
	const observer = new MutationObserver(applyTheme);
	observer.observe(img, { attributes: true, attributeFilter: ["src"] });
	}
});