


var currentSite = 'dariknews.bg';
currentSite=window.location.hostname;
if(currentSite.indexOf('gong.bg') !== -1){//for subdomains
	currentSite='gong.bg';
}


var verticalsmapping = {};
verticalsmapping['dariknews.bg'] = 
{
'bylgariia':'news',
'sviat':'news',
'biznes':'bussines',
'interviu':['news','entertianment','bussines'],
'komentar':['news','bussines'],
'liubopitno':'lifestyle_hobbies',
'obshtestvo':['entertianment','lifestyle_hobbies'],
'novini':'news',
};

verticalsmapping['www.vesti.bg'] = 
{
'bulgaria':'news',
'sviat':'news',
'avtomobili':['automoto','lifestyle_hobbies'],
'kompyutri-i-djadji':'technology_games',
'nauka-i-tehnika':'technology_games',
'zdravoslovno':['lifestyle_hobbies','health_beauty'],
'hranene':['lifestyle_hobbies','health_beauty','lifestyle_hobbies'],
'tonus':['health_beauty','health_beauty'],
'uchenite-kazvat':['health_beauty','technology_games'],
'radostta-ot-dvijenieto':['health_beauty','lifestyle_hobbies','lifestyle_hobbies'],
'shtastie':['lifestyle_hobbies','technology_games'],
'shoubiznes':'entertianment',
'kultura':'entertianment',
'zagadki-i-misterii':'lifestyle_hobbies',
'shoubiznes':'entertianment',
'puteshestvia':['health_beauty','lifestyle_hobbies','lifestyle_hobbies'],
'istoriata-pomni':'entertianment',
'sveji':'entertianment',
'testove':'entertianment',
'tema-novoto-bylgarsko-kino':['entertianment','lifestyle_hobbies'],
'tehnologii':'technology_games',
};
verticalsmapping['m.vesti.bg'] = verticalsmapping['www.vesti.bg'];

verticalsmapping['www.edna.bg'] = 
{
'svobodno-vreme':['entertianment','lifestyle_hobbies'],
'foto':['entertianment','lifestyle_hobbies'],
'testove':['entertianment','lifestyle_hobbies'],
'vkusno':'health_beauty',
'byrzi-recepti':'health_beauty',
'zakuska':'health_beauty',
'prediastie':'health_beauty',
'suoi':'health_beauty',
'osnovni':'health_beauty',
'deserti':'health_beauty',
'kokteili':'health_beauty',
'vegetarianstvo':'health_beauty',
'tehniki':'health_beauty',
'kak-da':'lifestyle_hobbies',
'zdravoslovno':['health_beauty','health_beauty','health_beauty'],
'za-roditeli':'parents',
'moda-i-kozmetika':['health_beauty','lifestyle_hobbies'],
'izvestni':'entertianment',
'vuvforma':'sports',
'horoskopi':'lifestyle_hobbies',
'tip':'lifestyle_hobbies',
'kasmeti':'lifestyle_hobbies',
'secret':'lifestyle_hobbies',
'wallpapers':'lifestyle_hobbies',
'tarot':'lifestyle_hobbies',
'za-doma':['real','lifestyle_hobbies','parents'],
};
verticalsmapping['gong.bg'] = 
{
'mondial-2018':'sports',
'visha-liga':'sports',
'basketball':'sports',
'football-sviat':'sports',
'bg-football':'sports',
'volleyball':'sports',
'tenis':'sports',
'corner':'sports',

'motorni':['sports','automoto'],
'oshte-sport':['sports','technology_games'],
'yellow':['sports','lifestyle_hobbies'],

/*subcats, not gonna be used by the script*/
'nacionalen-tim':'news',
'parva-liga':'news',
'kupa-na-bulgaria':'news',
'evrouchastnici':'news',
'drugi':'news',
'fpl-fantasy-manager':'news',
'spasiavane-na-sedmicata':'news',
'igrach-na-macha':'news',
'gol-na-kruga':'news',
'legioneri':'news',
'anglia':'news',
'ispania':'news',
'italia':'news',
'germania':'news',
'francia':'news',
'shampionska-liga':'news',
'liga-evropa':'news',
'transferi':'news',
};
verticalsmapping['nova.bg'] = 
{
//here the ID's are in w2g.targeting.catid & w2g.targeting.subcatid 
//w2g.targeting.catid 
'2':'news',//Bulgaria
'8':['entertianment','lifestyle_hobbies','lifestyle_hobbies'],//entertainment
'12':'sports',//sport
'5':'news',//world
'7':'news',//crime
'13':['lifestyle_hobbies','health_beauty','health_beauty'],//health
//TODO w2g.targeting.subcatid 
};

var w2g = w2g || {};
w2g.targeting = w2g.targeting || {};

function addVerticalToTargeting(currvertical){
    if( (w2g.targeting['vertical'] === 'undefined' || w2g.targeting['vertical'] === null || !w2g.targeting['vertical']) ) {
        w2g.targeting['vertical'] = [currvertical];
    } else if(typeof currvertical !== 'undefined'){  
        if(w2g.targeting['vertical'].indexOf(currvertical) == -1){
            w2g.targeting['vertical'].push(currvertical);
        } else {
            
        }
    }
}


(function() {

	if( (currentSite=='www.sinoptik.bg' || currentSite=='m.sinoptik.bg') && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ){
		w2g.targeting['vertical'] = ['weather'];
	} else if (currentSite=='www.pariteni.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		w2g.targeting['vertical'] = ['bussines'];
	} else if (currentSite=='www.imoti.info' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		w2g.targeting['vertical'] = ['real'];
	} else if (currentSite=='www.carmarket.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		w2g.targeting['vertical'] = ['automoto'];
	} else {
	var categories = [];
	if(w2g.targeting.catid != undefined && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ){ /*this is only for nova.bg*/ categories=[w2g.targeting.catid]; } else { /*all the other sites*/  categories=w2g.targeting.cid; }
		if( typeof categories === 'object'){
				categories.forEach(function(category) {
					//console.log(category);
					if( verticalsmapping[currentSite][category] != undefined ) {
						console.log('Vertical - '+verticalsmapping[currentSite][category]);
						//if we have an array (multiple verticals for this category)
						if( typeof verticalsmapping[currentSite][category] === 'object'){
							verticalsmapping[currentSite][category].forEach(function(singlevertical) {
								//console.log('Array singlevertical '+singlevertical);
								currvertical=singlevertical;
								addVerticalToTargeting(currvertical);
							});
						} else {
							currvertical=verticalsmapping[currentSite][category];
							//console.log('String currvertical '+currvertical);
							addVerticalToTargeting(currvertical);
						}
					} else {
						//mapping not found for this category. Either send default vertical or send nothing. Talk to Varov about it.
					}
				});
			}
		
	}
	
	//additional verticals for all pages on Darik, Gong and Vesti
	if (currentSite=='www.vesti.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		addVerticalToTargeting('news');
	} else if (currentSite=='dariknews.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		addVerticalToTargeting('news');
	} else if (currentSite=='gong.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		addVerticalToTargeting('sport');
	} else if (currentSite=='www.edna.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		addVerticalToTargeting('lifestyle_hobbies');
	} else if (currentSite=='nova.bg' && (w2g.targeting.safe === undefined || w2g.targeting.safe=="1") ) {
		addVerticalToTargeting('news');
	}
	
	
	
	
		
				/*Track consent ration*/

				
				

				
				
				
				
})();






/* //Track consent ratio

                function getCookie(name) {
                    var value = "; " + document.cookie;
                    var parts = value.split("; " + name + "=");
                    if (parts.length == 2) return parts.pop().split(";").shift();
                }
				

				setTimeout(sentConsent, 1000);
				
				function sentConsent(){
					var consentBit = '0';
					if(/2{5,15}/.test(getCookie('netinfo_consent_bit'))){
						consentBit = '1';
					}
					if( typeof _gaq === 'object'){
						_gaq.push(['_trackEvent', 'userConsent', 'consent - '+consentBit]);//old GA account
						console.log('Consent sent to GA');
					} else {
						console.log('Consent NOT sent to GA');
					}
					if(typeof dataLayer === 'object'){
						dataLayer.push({'event': 'userConsent', 'consent': consentBit});//GTM
					}
				}

//Track consent ration
*/





/*Gemius consent*/

function consentGemius(){
	if (typeof __tcfapi !== 'undefined') {
		__tcfapi('getTCData', 2, function(tcData) {
				/*if(!tcData.purpose.consents[1] && !tcData.purpose.consents[3] && !tcData.purpose.consents[4] && !tcData.purpose.consents[29] && !tcData.purpose.consents[39]){
					var pp_gemius_dnt = 1;
					console.log('#cnst No consent');
				} else {
					console.log('#cnst Full consent');
				}*/
			console.log('Publisher Consents', tcData);
		}); 
	} else {
		console.log('#cnst CMP object for consent not defined'); 
	}
}

consentGemius();
setTimeout(consentGemius, 300);
setTimeout(consentGemius, 1000);
setTimeout(consentGemius, 2000);

/*Gemius cnnsent*/
